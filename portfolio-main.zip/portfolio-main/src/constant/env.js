const ENV = {
  OPENAI_API_KEY: "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",
};
export default ENV;
