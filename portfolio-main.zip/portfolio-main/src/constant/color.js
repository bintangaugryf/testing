const COLOR = {
  MAIN_BG: "#FDF4F5",
  MAIN_COLOR: "#E8A0BF",
  SECOND_COLOR: "#BA90C6",
  MAIN_BLUE: "#4299e1",
};
export default COLOR;
